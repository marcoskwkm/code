#include <bits/stdc++.h>

#include "book.h"
#include "common.h"
#include "grader.h"
#include "library.h"

using namespace std;

lint getScore(const vector<Library*> &libraries, int B, int L, int D) {
    vector<bool> book_scanned(B, 0);

    cout << book_scanned.size() << endl;

    lint elapsed_time = 0;
    return 0;
}
