#include "flags.h"

int VERBOSE_MODE = 0;
