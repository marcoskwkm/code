#include "common.h"

int B, L, D;
