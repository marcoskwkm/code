#ifndef FLAGS_H
#define FLAGS_H

extern int VERBOSE_MODE;

#endif
