#ifndef GRADER_H
#define GRADER_H

#include <bits/stdc++.h>

#include "common.h"
#include "library.h"

using namespace std;

lint getScore(const vector<Library*> &libraries, int B, int L, int D);

#endif
